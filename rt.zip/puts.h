/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   puts.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nosuzuki <nosuzuki@student.42tokyo.jp>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/15 19:19:18 by nosuzuki          #+#    #+#             */
/*   Updated: 2021/03/06 06:42:41 by nosuzuki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUTS_H
# define PUTS_H
# include <stdio.h>
# include <stdlib.h>
# include <math.h>
# include <float.h>
# include "libft/libft.h"
# include "get_next_line.h"
# include <fcntl.h>
# define PI 3.14159265
# define BMP_MAX 3000
# define AMB 0.1
# define GLOSS 8
// # define AMB 1
// # define DIFF 0.69 * 0.9
# define DIFF 0.5
// # define SPEC 0.9
# define SPEC 0.3
typedef struct s_olist	t_olist;
typedef struct s_clist	t_clist;
typedef struct s_llist	t_llist;
typedef struct s_img	t_img;
typedef struct	s_rgb
{
	double		r;
	double		g;
	double		b;
}				t_rgb;
typedef struct	s_vect
{
	double		x;
	double		y;
	double		z;
	double		len;
}				t_vect;

typedef struct	s_sp
{
	t_vect		o;
	double		r;
	t_rgb		rgb;
}				t_sp;
typedef struct	s_sq
{
	t_vect		p;
	t_vect		n;
	t_vect		my;
	t_rgb		rgb;
	double		size;
}				t_sq;
typedef struct	s_pl
{
	t_vect		p;
	t_vect		n;
	t_rgb		rgb;
}				t_pl;
typedef struct	s_cy
{
	t_vect		p;
	t_vect		n;
	double		r;
	double		h;
	t_rgb		rgb;
}				t_cy;
typedef struct	s_tr
{
	t_vect		o;
	t_vect		p;
	t_vect		q;
	t_rgb		rgb;
}				t_tr;
typedef struct	s_node
{
	t_vect		pos;
	t_vect		normal;
	t_rgb		rgb;
	double		pos_len;
}				t_node;
struct  s_olist
{
	void		*obj;
	double		(*f)();
	t_olist		*next;
};
struct  s_clist
{
	t_vect		pos;
	t_vect		n;
	double		fov;
    char        *addr;
	t_vect		cent;
	t_clist		*next;
};
typedef struct s_llist
{
	t_vect		pos;
	t_rgb		rgb;
	double		pow;
	t_llist		*next;
}				t_llist;
struct  s_img
{
    void        *img;
	int			bmp;
	int			w;
	int			h;
    int         bpp;
    int         line_length;
    int         endian;
	void		*mlx;
	void		*win;
	t_rgb		rgb;
	t_llist		*amb;
	t_node		node;
	t_olist		*lst;
	t_clist		*cam;
	t_llist		*light;
	t_olist		*o_start;
	t_clist		*c_start;
	t_llist		*l_start;
	double		fov;
	// t_vect		cam;
	t_vect		cam_normal;
	t_vect		view;
	int			bmp_w;
	int			bmp_h;
};
//win minus or int_max

void            my_mlx_pixel_put(t_img *data, int x, int y, int color);
int             close1(t_img *vars);
int             close2(int keycode, t_img *vars);
double			dot(t_vect v1, t_vect v2);
t_vect			cross(t_vect v1, t_vect v2);
t_vect			vect_add(t_vect v1, t_vect v2);
t_vect			vect_mult(t_vect v1, double d);
t_vect			vect_sub(t_vect v1, t_vect v2);
t_vect			point_to_vect(double x, double y, t_img img);
t_vect			vect_init(double x, double y, double z);
double			vect_len(t_vect v);
double			sphere(t_img *img, t_sp *sp);
double			quadratic_formula(double a, double b, double d);
t_vect			vect_unit(t_vect v);
double			light(t_img *img);
double			spec(t_vect u_view, t_vect u_light, t_vect u_normal, double cos_nl);
t_olist			*ft_lstadd_front_o(t_olist **lst, t_olist *new);
t_clist			*ft_lstadd_front_c(t_clist **lst, t_clist *new);
t_llist			*ft_lstadd_front_l(t_llist **lst, t_llist *new);
t_olist			*ft_lstnew_o(void *obj, void *func);
t_clist			*ft_lstnew_c(t_clist c);
t_llist			*ft_lstnew_l(t_llist l);
t_rgb			rgb_init(int r, int g, int b);
int				color(t_rgb obj, t_llist light, double ref);
void			read_rt(t_img *img, char *path);
int				pl_init(char *data, t_img *img);
int				sp1_init(char *data, t_img *img);
int				sq_init(char *data, t_img *img);
int				cy_init(char *data, t_img *img);
int				tr_init(char *data, t_img *img);
int				parse_resolution(char *start, t_img *img);
int				resolution_init(char *data, t_img *img, int64_t *flag);
int				amb_init(char *data, t_img *img, int64_t *flag);
int				cam_init(char *data, t_img *img, int64_t *flag);
int				light1_init(char *data, t_img *img, int64_t *flag);
int				ft_isspace(int c);
char			*skip_space(char *s);
char			*skip_not_space(char *s);
char			*trim_space(char **s);
int				comma_count(char *s);
int				split_count(char **s);
int				split_comma(char *s, double *a, double *b, double *c);
int				parse_rgb(char *s, double *r, double *g, double *b);
double			ft_mini_atoinf(const char *s, char type);
int				split_comma_normal(char *s, double *a, double *b, double *c);
int				check_range(char *s, char c);
double			plane(t_img *img, t_pl *pl);
double			square(t_img *img, t_sq *sq);
double			cylinder(t_img *img, t_cy *cy);
double			triangle(t_img *img, t_tr *tr);
int				check_parallel(t_vect a, t_vect b, t_vect c);
#endif